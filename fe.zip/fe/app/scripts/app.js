angular.module('todayTimes',['ui.router','ngResource'])

  .config(function($stateProvider,$urlRouterProvider){
    
    $stateProvider
    
      .state('app',{
            url:'/',
            views:{
             'header':{
                 templateUrl:'views/header.html',
                 controller:'DateCtrl'
             },
             'content':{
                templateUrl:'views/latest.html',
                controller:'NewsCtrl'
             },
             'footer':{
                 templateUrl:'views/footer.html'
                 }
               }
             })
    
       .state('app.nation',{
            url:'nation',
            views:{
             
             'content@':{
                templateUrl:'views/nation.html',
                controller:'NewsCtrl'
                 }
               }
             })
      
    .state('app.world',{
            url:'world',
            views:{
             
             'content@':{
                templateUrl:'views/world.html',
                controller:'NewsCtrl'
                 }
               }
             })
    .state('app.business',{
            url:'business',
            views:{
             
             'content@':{
                templateUrl:'views/business.html',
                controller:'NewsCtrl'
                 }
               }
             })
    
    .state('app.sports',{
            url:'sports',
            views:{
             
             'content@':{
                templateUrl:'views/sports.html',
                controller:'NewsCtrl'
                 }
               }
             })
    .state('app.entertainment',{
            url:'entertainment',
            views:{
             
             'content@':{
                templateUrl:'views/entertainment.html',
                controller:'NewsCtrl'
                 }
               }
             })
    .state('app.technology',{
            url:'technology',
            views:{
             
             'content@':{
                templateUrl:'views/technology.html',
                controller:'NewsCtrl'
                 }
               }
             })
       
       .state('app.newsdetail',{
            url:'news/:id',
            views:{
                'content@':{
                  templateUrl:'views/newsdetail.html',
                  controller:'NewsDetailCtrl'
                }
               }
            });
    
    $urlRouterProvider.otherwise('/');
    
     });


var skycons = new Skycons({"color": "black"});

skycons.add("animated-icon", Skycons.CLEAR_DAY);

skycons.play();

//Some Global variables

var longitude, latitude;

//Function to update weather information

function updateWeather (json) {

	longitude = json.coord.lon;
	latitude = json.coord.lat;
  
	//Update Weather parameters and location

	$(".weather-condition").html(json.weather[0].description);
var temp = [(json.main.temp - 273.15).toFixed(0) + "°C", (1.8 * (json.main.temp - 273.15) + 32).toFixed(0) + "F"];
	$(".temp-celsius").html(temp[0]);
	$(".temp-fahrenheit").html(temp[1]);
	$(".temperature").click(function () {
		$(".temp-celsius").toggle();
		$(".temp-fahrenheit").toggle();
	});
	$(".location").html("for " + json.name);

	//Update Weather animation based on the returned weather description

	var weather = json.weather[0].description;
	
	if(weather.indexOf("rain") >= 0) {
		skycons.set("animated-icon", Skycons.RAIN);
	}

	else if (weather.indexOf("sunny") >= 0) {
		skycons.set("animated-icon", Skycons.CLEAR_DAY);
	}

	else if (weather.indexOf("clear") >= 0) {
		
			skycons.set("animated-icon", Skycons.CLEAR_DAY);
			
	}

	else if (weather.indexOf("cloud") >= 0) {
		
			skycons.set("animated-icon", Skycons.PARTLY_CLOUDY_DAY);
  }

	else if (weather.indexOf("thunderstorm") >= 0) {
		skycons.set("animated-icon", Skycons.SLEET);
	}

	else if (weather.indexOf("snow") >= 0) {
		skycons.set("animated-icon", Skycons.SNOW);
	}
}

if (navigator.geolocation) {

	//Return the user's longitude and latitude on page load using HTML5 geolocation API

	window.onload = function () {
	var currentPosition;
	function getCurrentLocation (position) {
		currentPosition = position;
		latitude = currentPosition.coords.latitude;
		longitude = currentPosition.coords.longitude;

		//AJAX request
    $.getJSON("http://api.openweathermap.org/data/2.5/weather?lat=" + latitude + "&lon=" + longitude + "&APPID=71f72ecfd0af33dc26370b452cae2fbc", function (data) {
			var rawJson = JSON.stringify(data);
			var json = JSON.parse(rawJson);
			updateWeather(json); //Update Weather parameters
		});
	}

	navigator.geolocation.getCurrentPosition(getCurrentLocation);
	
	};


}

//If Geolocation is not supported by the browser, alert the user

else {
  alert("Geolocation is not supported by your browser, download the latest Chrome or Firefox to use this app");
}

