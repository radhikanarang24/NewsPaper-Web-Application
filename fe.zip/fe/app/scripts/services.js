angular.module('todayTimes')
      .constant("baseURL","http://localhost:3000/")
      .service('newsFactory',['$resource','baseURL',function($resource,baseURL){

          
          this.getAllNews = function(){
              return $resource(baseURL+"newsarr/:id",null,{'update':{method:'PUT'}});
          };
          
         /* this.getNews = function(index){
              return $http.get(baseURL+"newsarr/"+index);
          };*/
       
        

}]);