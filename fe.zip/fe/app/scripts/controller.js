angular.module('todayTimes')

   .controller('NewsCtrl',['$scope','newsFactory',function($scope,newsFactory){
    
       $scope.showNewsAll=false;
       $scope.message="Loading...";
       
       $scope.newsarray={};
       newsFactory.getAllNews().query(
       
          function(response){
              $scope.newsarray=response;
              $scope.showNewsAll=true;
              },
           function(response){
              $scope.message = "Error: "+response.status+" "+response.statusText;
           }
        );
    
    }])

   .controller('NewsDetailCtrl',['$scope','$stateParams','newsFactory',function($scope,$stateParams,newsFactory){
       
       $scope.showNews=false;
       $scope.message="Loading...";
       
       $scope.news={};
            newsFactory.getAllNews().get({id:parseInt($stateParams.id,10)})
         .$promise.then(
             function(response){
                 $scope.news=response;
                 $scope.showNews=true;
             },
            function(response){
                $scope.message = "Error: "+response.status+" "+response.statusText;
            }
         );
       
       
       
       $scope.togglePost = function() {
                $scope.showForm = !$scope.showForm;
            };
   }])

  .controller('DateCtrl',['$scope',function($scope){
    
    $scope.today = new Date();
    
   }])

.controller('NewsCommentCtrl',['$scope','newsFactory',function($scope,newsFactory){
    
    
   $scope.addComment=function(){
          if($scope.mycomment.body===''){return;}
           
           $scope.mycomment.date=new Date().toISOString().replace(/T.*/,'').split('-').reverse().join('-');
          console.log($scope.mycomment);
           
           $scope.news.comment.push($scope.mycomment);
           
           newsFactory.getAllNews().update({id:$scope.news.id},$scope.news);
         $scope.mycomment={body:"",author:"",date:""};
       }; 
    
    
}])

.controller('ActiveCtrl',['$scope','$location',function($scope,$location){
    $scope.activeClass = function(page){
        var current = $location.path().substring(1);
        console.log(current);
        return page === current ? "active" : "";
    }
}]);