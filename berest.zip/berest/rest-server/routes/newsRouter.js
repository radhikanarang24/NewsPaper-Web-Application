var express=require('express');
var bodyParser=require('body-parser');
var mongoose = require('mongoose');

var News = require('../models/newsSchema');
var Verify = require('./verify'); 

var newsRouter = express.Router();

newsRouter.use(bodyParser.json());

newsRouter.route('/')

.get(function(req,res,next){
   News.find(req.query)
        .populate('comment.author')
        .exec(function(err,news){
         if (err) return next(err);
       res.json(news);
   });
})

.post(Verify.verifyOrdinaryUser,Verify.verifyAdmin,function(req,res,next){
  News.create(req.body,function(err,news){
       if (err) return next(err);
      console.log('News created!');
      var id=news._id;
      
      res.writeHead(200,{
          'Content-Type':'text/plain'
      });
      
      res.end('Added the news with id:'+id);
  });  
})

.delete(Verify.verifyOrdinaryUser,Verify.verifyAdmin,function(req,res,next){

    News.remove({},function(err,resp){
         if (err) return next(err);
        res.json(resp);
    });
});

newsRouter.route('/:newsId')

.get(function(req,res,next){
    News.findById(req.params.newsId)
                  .populate('comment.author')
                  .exec(function(err,news){
         if (err) return next(err);
        res.json(news);
    });
})

.put(Verify.verifyOrdinaryUser,Verify.verifyAdmin,function(req,res,next){
    News.findByIdAndUpdate(req.params.newsId,{
        $set:req.body
    },{
        new:true
    },
        function(err,news){
          if (err) return next(err);
        res.json(news);
    });
})

.delete(Verify.verifyOrdinaryUser,Verify.verifyAdmin,function(req,res,next){
    News.findByIdAndRemove(req.params.newsId,function(err,resp){
        if (err) return next(err);
        res.json(resp);
    });
});

newsRouter.route('/:newsId/comment')

.get(function(req,res,next){
    News.findById(req.params.newsId)
        .populate('comment.author')
       .exec(function(err,news){
         if (err) return next(err);
        res.json(news.comment);
    });
})

.post(Verify.verifyOrdinaryUser,function(req,res,next){
    News.findById(req.params.newsId,function(err,news){
         if (err) return next(err);
        req.body.author=req.decoded._id;
        news.comment.push(req.body);
        news.save(function(err,news){
             if (err) return next(err);
            console.log('updated comments!');
            res.json(news);
        });
    });
})


.delete(Verify.verifyOrdinaryUser,Verify.verifyAdmin,function(req,res,next){
    News.findById(req.params.newsId,function(err,news){
         if (err) return next(err);
        
        for(var i = (news.comment.length - 1);i>=0;i--){
            news.comment.id(news.comment[i]._id).remove();
        }
        news.save(function(err,result){
             if (err) return next(err);
            res.writeHead(200,{
                'Content-Type':'text/plain'
            });
            res.end('Deleted all comments!');
        });
    });
});

newsRouter.route('/:newsId/comment/:commentId')

.get(Verify.verifyOrdinaryUser,function(req,res,next){
    News.findById(req.params.newsId)
        .populate('comment.author')
        .exec(function(err,news){
         if (err) return next(err);
        res.json(news.comment.id(req.params.commentId));
    });
})

.put(Verify.verifyOrdinaryUser,function(req,res,next){
    News.findById(req.params.newsId,function(err,news){
          if (err) return next(err);
        news.comment.id(req.params.commentId).remove();
        req.body.author=req.decoded._id;
        news.comment.push(req.body);
        news.save(function(err,news){
             if (err) return next(err);
            console.log('updated comments');
            res.json(news);
            });
    });    
})

.delete(Verify.verifyOrdinaryUser,function(req,res,next){
    News.findById(req.params.newsId,function(err,news){
        
        if(news.comment.id(req.params.commentId).author != req.decoded._id){
            var err = new Error('you are not authorized to perform this operation!');
            err.status = 403;
            return next(err);
        }
    
        news.comment.id(req.params.commentId).remove();
        news.save(function(err,resp){
              if (err) return next(err);
            res.json(resp);
            console.log('deleted the comment');
        });
    });
});

module.exports = newsRouter;
