module.exports = {
    'secretKey':'12345-67890-09876-54321',
    'mongoUrl':'mongodb://localhost:27017/todayTimes',
    'facebook':{
       
        clientID:'1380574268660504',
        clientSecret:'0fe605b3f8caa58a73daa66090075910',
        callbackURL:'https://localhost:3443/users/facebook/callback'
        
         },
    
    'google':{
       
        clientID:'540247828957-l4ijqet3loi0s5d5n29qvioo5q02jvrh.apps.googleusercontent.com',
        clientSecret:'-2BiBx1kg02TzibltOI9MZRG',
        callbackURL:'https://localhost:3443/users/google/callback'
        
         }
}