var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var commentSchema = new Schema({
   
    body:{
       type:String,
        required:true
    },
    date:{
        type: Date,
        default:Date.now
    },
    author:{
       type:mongoose.Schema.Types.ObjectId,
       ref:'User'
   }
},{
    timestamps:true
});

var newsSchema = new Schema({
    type:{
        type: String,
        required: true
         },
    image:{
        type:String,
        default:'http://www.globalmarinesystems.com/uploads/images/default-news-image.jpg'
    },
    head:{
        type:String,
        required:true
    },
    para:{
        type:String,
        required:true
    },
    description:{
        type:String
    },
    featured: {
        type: Boolean,
        default:false
    },
    comment:[commentSchema]
},{
    timestamps: true
});

var News = mongoose.model('News',newsSchema);

module.exports = News;
